import Login from "@/components/Login";

function login() {
    return (<Login />)
}

export default login;