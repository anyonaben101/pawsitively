function about() {
    return ( <div>
        <h1>About</h1>
    </div> );
}

export default about;